const {exports,test}=require("@playwright/test")
const {RedBus}=require("../../Redbus/class/RedBus") 

test("Booka a bus in REDBUS",async({page})=>
{
    var homePage=new RedBus(page)
    await homePage.openURL() 
    await page.waitForLoadState("networkidle")
    await homePage.bookBus()
    await page.waitForTimeout(5000)
    await homePage.userdateselect()
    await homePage.alllinks()
    // await page.locator("").click()
    // await page.locator("//span[@class='DayTiles__CalendarDaysSpan-sc-1xum02u-1 fgdqFw']").click()
    // await page.locator("//button[@id='search_button']").click();
    // await page.locator("").click()
    // await page.waitForTimeout(13000)
    // await page.locator("//li[@id='26918574']//div[@class='clearfix bus-item']").click()
    // await page.locator("//li[@id='26918574']//div//span[contains(@class,'txt-val')][normalize-space()='Amenities']").click()
    // await page.locator("//li[@id='26918574']//div//span[contains(@class,'txt-val')][normalize-space()='Bus Photos']").click()
    // await page.locator("//li[@id='26918574']//div//span[contains(@class,'txt-val')][normalize-space()='Boarding & Dropping Points']").click()
    // await page.locator("//li[@id='26918574']//div//span[contains(@class,'txt-val')][normalize-space()='Reviews']").click()
   
    
    
})